# 🖱️ Virtual Mouse — Hand Gesture Control

Control your PC mouse entirely with your hand in front of a webcam.
Built with Python + OpenCV + MediaPipe + PyAutoGUI.

---

## 📦 Install Dependencies

```bash
pip install opencv-python mediapipe pyautogui numpy
```

> On Linux you may also need:
> ```bash
> sudo apt install python3-tk python3-dev
> pip install python3-xlib
> ```

---

## ▶️ Run

```bash
python virtual_mouse.py
```

Press **Q** or **ESC** to quit.

---

## 🤚 Gesture Reference

| Gesture | Action |
|---|---|
| ☝️ Index finger up | **Move** cursor |
| 🤏 Pinch (index + thumb) | **Left click** |
| 🤟 Three fingers (index+middle+ring) | **Right click** |
| 🤙 Pinky only | **Double click** |
| ✊ Fist | **Scroll** (move hand up/down) |
| ✌️ Index + Middle up | **Freeze** (no action) |

---

## 🛠️ Customise

Open `virtual_mouse.py` and tweak:

```python
SMOOTH        = 5      # Cursor smoothing (higher = smoother but slower)
CLICK_COOLDOWN = 0.35  # Seconds between clicks
ROI_LEFT/RIGHT/TOP/BOTTOM  # Active zone within camera frame
```

---

## 📋 Requirements

- Python 3.8+
- Webcam
- Windows / macOS / Linux (X11)
