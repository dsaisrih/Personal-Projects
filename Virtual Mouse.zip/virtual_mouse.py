"""
Virtual Mouse App using Hand Gestures + Camera
============================================
Controls:
  - INDEX finger UP       → Move mouse cursor
  - INDEX + MIDDLE up     → Freeze (no click)
  - Pinch (index + thumb) → LEFT click
  - THREE fingers up      → RIGHT click
  - FIST (all down)       → SCROLL mode (move hand up/down)
  - PINKY up alone        → DOUBLE click
  - Press 'Q' or ESC     → Quit
"""

import cv2
import mediapipe as mp
import pyautogui
import numpy as np
import time
import math
import sys

# ── Safety ──────────────────────────────────────────────────────────────────
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0

# ── Screen size ──────────────────────────────────────────────────────────────
SCREEN_W, SCREEN_H = pyautogui.size()

# ── Smoothing buffer ─────────────────────────────────────────────────────────
SMOOTH = 5          # frames to average
prev_x, prev_y = [], []

# ── Gesture cooldowns ────────────────────────────────────────────────────────
last_click_time   = 0
CLICK_COOLDOWN    = 0.35   # seconds

# ── MediaPipe setup ──────────────────────────────────────────────────────────
mp_hands   = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_styles  = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    model_complexity=1,
    min_detection_confidence=0.75,
    min_tracking_confidence=0.75,
)

# ── Landmark aliases ─────────────────────────────────────────────────────────
WRIST          = 0
THUMB_TIP      = 4
INDEX_MCP      = 5
INDEX_TIP      = 8
MIDDLE_TIP     = 12
RING_TIP       = 16
PINKY_TIP      = 20
INDEX_PIP      = 6
MIDDLE_PIP     = 10
RING_PIP       = 14
PINKY_PIP      = 18

# ── Helpers ──────────────────────────────────────────────────────────────────
def dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)

def fingers_up(lm):
    """Return list of booleans [thumb, index, middle, ring, pinky]."""
    tips  = [THUMB_TIP, INDEX_TIP, MIDDLE_TIP, RING_TIP, PINKY_TIP]
    pips  = [2,         INDEX_PIP, MIDDLE_PIP, RING_PIP, PINKY_PIP]
    up = []
    # Thumb: compare x (assumes right hand facing camera)
    up.append(lm[THUMB_TIP].x < lm[2].x)
    for tip, pip in zip(tips[1:], pips[1:]):
        up.append(lm[tip].y < lm[pip].y)
    return up

def smooth_point(x, y):
    prev_x.append(x)
    prev_y.append(y)
    if len(prev_x) > SMOOTH:
        prev_x.pop(0)
        prev_y.pop(0)
    return int(np.mean(prev_x)), int(np.mean(prev_y))

def map_range(val, in_min, in_max, out_min, out_max):
    val = max(in_min, min(in_max, val))
    return int((val - in_min) / (in_max - in_min) * (out_max - out_min) + out_min)

# ── Overlay helpers ──────────────────────────────────────────────────────────
def draw_rounded_rect(img, x1, y1, x2, y2, r, color, alpha=0.55):
    overlay = img.copy()
    cv2.rectangle(overlay, (x1 + r, y1), (x2 - r, y2), color, -1)
    cv2.rectangle(overlay, (x1, y1 + r), (x2, y2 - r), color, -1)
    for cx, cy in [(x1+r, y1+r), (x2-r, y1+r), (x1+r, y2-r), (x2-r, y2-r)]:
        cv2.circle(overlay, (cx, cy), r, color, -1)
    cv2.addWeighted(overlay, alpha, img, 1 - alpha, 0, img)

def put_text(img, text, pos, scale=0.6, color=(255,255,255), thickness=1):
    cv2.putText(img, text, pos, cv2.FONT_HERSHEY_SIMPLEX, scale, (0,0,0), thickness+2, cv2.LINE_AA)
    cv2.putText(img, text, pos, cv2.FONT_HERSHEY_SIMPLEX, scale, color,  thickness,   cv2.LINE_AA)

# ── Gesture detect ───────────────────────────────────────────────────────────
def detect_gesture(lm):
    fu = fingers_up(lm)
    thumb, index, middle, ring, pinky = fu

    pinch_d = dist(lm[THUMB_TIP], lm[INDEX_TIP])

    # Scroll: fist (all fingers down)
    if not any(fu):
        return "SCROLL"
    # Double-click: only pinky up
    if pinky and not index and not middle and not ring:
        return "DOUBLE_CLICK"
    # Right-click: three fingers (index+middle+ring)
    if index and middle and ring and not pinky:
        return "RIGHT_CLICK"
    # Left-click: pinch (index+thumb close, others can be anything)
    if pinch_d < 0.055 and index:
        return "LEFT_CLICK"
    # Freeze: index+middle up
    if index and middle and not ring and not pinky:
        return "FREEZE"
    # Move: only index up
    if index and not middle:
        return "MOVE"

    return "IDLE"

# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    global last_click_time

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌  Cannot open camera. Connect a webcam and retry.")
        sys.exit(1)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_FPS, 30)

    # ROI margins (fraction of frame)
    ROI_LEFT, ROI_TOP, ROI_RIGHT, ROI_BOTTOM = 0.10, 0.10, 0.90, 0.85

    scroll_ref_y  = None
    gesture_label = "No hand"
    fps_timer     = time.time()
    fps           = 0
    frame_count   = 0

    print("✅  Virtual Mouse running — press Q or ESC to quit")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        h, w  = frame.shape[:2]
        frame_count += 1

        # ── FPS ──
        if frame_count % 15 == 0:
            fps = 15 / (time.time() - fps_timer + 1e-9)
            fps_timer = time.time()

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = hands.process(rgb)

        # ── ROI rectangle ──
        rx1, ry1 = int(ROI_LEFT*w), int(ROI_TOP*h)
        rx2, ry2 = int(ROI_RIGHT*w), int(ROI_BOTTOM*h)
        cv2.rectangle(frame, (rx1, ry1), (rx2, ry2), (100, 200, 255), 2)

        if res.multi_hand_landmarks:
            lm_list = res.multi_hand_landmarks[0].landmark

            # Draw skeleton
            mp_drawing.draw_landmarks(
                frame,
                res.multi_hand_landmarks[0],
                mp_hands.HAND_CONNECTIONS,
                mp_styles.get_default_hand_landmarks_style(),
                mp_styles.get_default_hand_connection_style(),
            )

            gesture = detect_gesture(lm_list)
            gesture_label = gesture.replace("_", " ")

            # Index fingertip position (normalised inside ROI)
            ix = lm_list[INDEX_TIP].x
            iy = lm_list[INDEX_TIP].y

            mouse_x = map_range(ix, ROI_LEFT, ROI_RIGHT,  0, SCREEN_W)
            mouse_y = map_range(iy, ROI_TOP,  ROI_BOTTOM, 0, SCREEN_H)
            sx, sy  = smooth_point(mouse_x, mouse_y)

            now = time.time()

            if gesture == "MOVE":
                pyautogui.moveTo(sx, sy)
                # Draw cursor dot
                fx = int(ix * w)
                fy = int(iy * h)
                cv2.circle(frame, (fx, fy), 12, (0, 255, 100), -1)
                cv2.circle(frame, (fx, fy), 12, (255,255,255),  2)

            elif gesture == "LEFT_CLICK":
                if now - last_click_time > CLICK_COOLDOWN:
                    pyautogui.click(sx, sy)
                    last_click_time = now
                    gesture_label = "LEFT CLICK ✓"

            elif gesture == "RIGHT_CLICK":
                if now - last_click_time > CLICK_COOLDOWN:
                    pyautogui.rightClick(sx, sy)
                    last_click_time = now
                    gesture_label = "RIGHT CLICK ✓"

            elif gesture == "DOUBLE_CLICK":
                if now - last_click_time > CLICK_COOLDOWN * 2:
                    pyautogui.doubleClick(sx, sy)
                    last_click_time = now
                    gesture_label = "DOUBLE CLICK ✓"

            elif gesture == "SCROLL":
                if scroll_ref_y is None:
                    scroll_ref_y = iy
                delta = (scroll_ref_y - iy) * 30
                if abs(delta) > 0.5:
                    pyautogui.scroll(int(delta))
                gesture_label = f"SCROLL {'↑' if delta>0 else '↓'}"
            else:
                scroll_ref_y = None

            if gesture != "SCROLL":
                scroll_ref_y = None

        else:
            gesture_label = "No hand detected"

        # ─── HUD ────────────────────────────────────────────────────────────
        # Top bar
        draw_rounded_rect(frame, 0, 0, w, 48, 0, (20, 20, 40), alpha=0.7)
        put_text(frame, "🖱  Virtual Mouse",       (12,  32), 0.75, (100, 220, 255), 2)
        put_text(frame, f"FPS: {fps:.0f}",         (w-120, 32), 0.65, (180, 255, 180))
        put_text(frame, f"Screen: {SCREEN_W}x{SCREEN_H}", (w-320, 32), 0.55, (200,200,200))

        # Gesture badge
        g_color = {
            "MOVE":         (50,  220, 50),
            "LEFT CLICK ✓": (50,  180, 255),
            "RIGHT CLICK ✓":(255, 150, 50),
            "DOUBLE CLICK ✓":(200,50, 255),
            "FREEZE":       (200, 200, 50),
            "SCROLL ↑":     (50,  200, 255),
            "SCROLL ↓":     (50,  200, 255),
        }.get(gesture_label, (180, 180, 180))

        badge_x = 12
        draw_rounded_rect(frame, badge_x, h-60, badge_x+320, h-12, 10, (20,20,40), 0.7)
        put_text(frame, f"Gesture: {gesture_label}", (badge_x+12, h-28), 0.65, g_color, 2)

        # Legend (bottom-right)
        legend = [
            "INDEX up     → Move",
            "Pinch        → Left click",
            "3 fingers    → Right click",
            "PINKY only   → Double click",
            "FIST         → Scroll",
            "INDEX+MIDDLE → Freeze",
            "Q / ESC      → Quit",
        ]
        lx, ly = w - 260, h - len(legend)*22 - 20
        draw_rounded_rect(frame, lx-8, ly-8, w-8, h-8, 8, (15, 15, 35), 0.65)
        for i, line in enumerate(legend):
            put_text(frame, line, (lx, ly + i*22), 0.42, (210, 210, 230))

        cv2.imshow("Virtual Mouse — Hand Gesture Control", frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord('q'), ord('Q'), 27):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("👋  Virtual Mouse closed.")

if __name__ == "__main__":
    main()
